function send_ajax_req(url, dataItems, follow_up_func, follow_up_func_err) {
    // url: file url to submit data
    // dataItems: Json data object to submit
    // follow up func: function to run after a backend response
    // follow up func err: a function to run after an error has occured
    $.ajax({

        type: "POST",
        url: url,
        data: dataItems,
        dataType:"JSON",

        success:function (data) {
            data = data;
            // console.log(data)
            // Follow function has to accept the response data
            follow_up_func(data);
        },
        error:function (jqXHR, textStatus, errorThrown){
            data = '';
            console.log(errorThrown)
            follow_up_func_err(dataItems);
        }

    });
}