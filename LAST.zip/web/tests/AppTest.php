<?php

use PHPUnit\Framework\TestCase;

include_once __DIR__ . '/../includes/functions.php';

class AppTest extends TestCase
{
    /**
     * Test our PDO Connection
     * 
     * @test
     *
     * @return void
     */
    public function testPDOConnection()
    {
        $this->assertInstanceOf(PDO::class, getPDOConnection());
    }

    /**
     * Test our MySQL Connection
     * @test
     *
     * @return void
     */
    public function testMySQLiConnection()
    {
        $this->assertInstanceOf(mysqli::class, getMySQLiConnection());
    }

    /**
     * Test our login function
     * 
     * @return void
     */
    public function testLogin() 
    {
        $loginResponse = userLogin('johndoe', 'password'); 

        $this->assertIsArray($loginResponse);
        $this->assertArrayHasKey('message', $loginResponse);
        $this->assertArrayHasKey('profile', $loginResponse);

        // assert key equals value
        $this->assertEquals('success', $loginResponse['message']);
    }

    /**
     * Test our register function
     * 
     * @return void
     */
    public function testRegister()
    {
        $registerResponse = registerUser(date('U'), 'test');

        $this->assertIsArray($registerResponse);
        $this->assertArrayHasKey('status', $registerResponse);

        // assert key equals value
        $this->assertEquals(true, $registerResponse['status']);
    }

    /**
     * getQuote function
     *
     * @return void
     */
    public function testGetQuote()
    {
        $getQuoteResponse = getQuote(1500, "01");

        $this->assertIsArray($getQuoteResponse);
        $this->assertArrayHasKey('suggested_price', $getQuoteResponse);
        $this->assertArrayHasKey('total_amount', $getQuoteResponse);

        // assert key equals value
        $this->assertEquals(round(ceil(1.695*100)/100,2), round(ceil($getQuoteResponse['suggested_price']*100)/100,1));
        $this->assertEquals(2542.5, $getQuoteResponse['total_amount']);

    }
}