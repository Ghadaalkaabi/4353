<?php
ini_set('display_errors', 1);

// Database host
define('DB_HOST', 'localhost');
// Database username
define('DB_USER', 'root');
// Database password
define('DB_PASS', '');
// Database name
define('DB_NAME', 'fuel_prediction_db');

define('DB_STRING', 'mysql:host='.DB_HOST.';dbname='.DB_NAME);
	
function getPDOConnection(){
    $db = new PDO(DB_STRING, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $db;
}

function getMySQLiConnection(){
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset("utf8");
    return $db;
}

// start session if not already started
if(headers_sent() == false) {
    session_start();
}

if(! isset($_SESSION['fuel_client_logged_in'])) {
    $_SESSION['fuel_client_logged_in'] = false;
}

