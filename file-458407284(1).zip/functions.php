<?php
/************************************************************
 * 
 * Always include config.php before any other file
 * 
 * **********************************************************
 */
include_once 'config.php';


// start session if not already started
if(headers_sent() == false) {
    session_start();
}

/************************************************************
 * 
 * Fuel functions
 * 
 * **********************************************************
 */
function addFuelQuote($gallons, $date, $suggested, $total, $userid = null, $address = null)
{
    $con = getMySQLiConnection();

    $response = array();

    if (is_null($userid)) {
        $userid = $_SESSION['id'];
    }
    if (is_null($address)) {
        $address = $_SESSION['address'];
    }

    $stmt = $con->prepare("INSERT INTO `fuelquote`(`userid`, `gallons_requested`, `delivery_address`, `delivery_date`, `suggested_price`, `total_amount`) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $userid, $gallons, $address, $date, $suggested, $total);

    if ($stmt->execute()) {

        $response['message'] = "Fuel Quote Added successfully";
        $response['status'] = "success";

    } else {
        
        $response['message'] = "Unable to add Fuel Quote.";
        $response['status'] = "failed";

    }

    $stmt->close();

    return $response;
}

function getHistory($userid = null) {
    $db = getPDOConnection();
    $con = getMySQLiConnection();

    $response = array();

    if(is_null($userid)){
        $userid = $_SESSION['id'];
    }

    $query  = "SELECT id, gallons_requested, delivery_address, delivery_date, suggested_price, total_amount FROM fuelquote WHERE userid = '$userid'";
    $statement = $db->prepare($query);
        $output = '
        <div class="table-responsive" id="assignment-table">
            <table class="table table-bordered table-striped" id="table_questions">
                <tr id="tr_title">
                    <th width="20%">Gallons Requested.</th>
                    <th width="35%">Delivery Address</th>
                    <th width="15%">Delivery Date</th>
                    <th width="15%">Suggested Price</th>
                    <th width="15%">Total Amount</th>
                    
                </tr>

        ';

    if ($statement->execute()) {
        $result = $statement->fetchAll();
        $fetch_results = mysqli_query($con, $query);
        $result_row = mysqli_fetch_array($fetch_results, MYSQLI_ASSOC);
        if($result_row) {
            
            foreach ($result as $row) {
                $id = $row["id"];
                $gallons_requested = $row["gallons_requested"];
                $delivery_address = $row["delivery_address"];
                $delivery_date = $row["delivery_date"];
                $suggested_price = $row["suggested_price"];
                $total_amount = $row["total_amount"];

                $output .= '
                    <tr class="tr_body">
                        <td align="right">'.$gallons_requested.'</td>
                        <td align="right">'.$delivery_address.'</td>
                        <td align="right">'.$delivery_date.'</td>
                        <td align="right">'.$suggested_price.'</td>
                        <td align="right">'.$total_amount.'</td>
                    
                    </tr>
                
                    ';

            }
            $output .= '</table></div>';
            $response['output'] = $output;
            $response['message'] = "success";
        } else {
            $output .= '
                <tr>
                    <td colspan="5" align="center">No record found at the moment.</td>
                </tr>
                ';
                $output .= '</table></div>';
            $response['output'] = $output;

            $response['message'] = "none";
        }
    } else {
        $output .= '
                <tr>
                    <td colspan="5" align="center">No record found at the moment.</td>
                </tr>
                ';
        $output .= '</table></div>';
        $response['output'] = $output;

        $response['message'] = "none";
    }

    return $response;
}



/************************************************************
 * 
 * Login functions
 * 
 * **********************************************************
 */
function registerUser($username, $password)
{
    $con = getMySQLiConnection();
    $response = array();
    $pass_hash = password_hash($password, PASSWORD_BCRYPT, ["COST"=>8]);
    $stmt = $con->prepare("INSERT INTO `usercredentials`(`username`, `password`) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $pass_hash);

    if ($stmt->execute()) {
        $response['message'] = "User registered successfully";
        $response['status'] = "success";
        
    } else {
        
        $response['message'] = "Username exists on the system. Try again with different username.";
        $response['status'] = "failed";

    }

    return $response;
}

function userLogin($username, $password){
    $con = getMySQLiConnection();
    $response = array();

    $sql = $con->prepare("select id, username, password from usercredentials where username = ? limit 1");
    $sql->bind_param("s", $username);
    $sql->execute();

    $result = $sql->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        $getid = $row["id"];
        $username = $row["username"];
        $getpassword = $row["password"];

        if (password_verify($password, $getpassword)) {
            $sql_profile = $con->prepare("select id, address1, state from clientinformation where userid = ?");
            $sql_profile->bind_param("s", $getid);
            $sql_profile->execute();

            $result_profile = $sql_profile->get_result();
            if ($result_profile->num_rows > 0) {
                $row_profile = $result_profile->fetch_assoc();
                $response['message'] = "success";
                $response['id'] = $getid;
                $response['username'] = $username;
                $response['profile'] = "true";

                $_SESSION['id'] = $getid;
                $_SESSION['username'] = $username;
                $_SESSION['address'] = $row_profile["address1"];
                $_SESSION['state'] = $row_profile["state"];
            } else {
                $response['message'] = "success";
                $response['id'] = $getid;
                $response['username'] = $username;
                $response['profile'] = "false";

                $_SESSION['id'] = $getid;
                $_SESSION['username'] = $username;

            }

        }else{
            $response['message'] = "failed";
        }
        
    }else{
        $response['message'] = "failed";
    }

    return $response;
}

function getAddress()
{
    $response = array();
    $response['address'] = $_SESSION['address'];

    return $response;
}


/************************************************************
 * 
 * Pricing functions
 * 
 * **********************************************************
 */
function getQuote($gallons, $state = null)
{
    $response = array();

    if(is_null($state)){
        $state = $_SESSION['state'];
    }
    
    $current_price = 1.5;
    $location_factor = 0;
    $rate_history_factor = 0;
    $gallons_requested_factor = 0;
    $company_profit_factor = 0.1;

    if ($state == "01") {
        $location_factor = 0.02;
    } else {
        $location_factor = 0.04;
    }
    if (hasHistory()) {
        $rate_history_factor = 0.01;
    } else {
        $rate_history_factor = 0;
    }
    if ($gallons > 1000) {
        $gallons_requested_factor = 0.02;
    } else {
        $gallons_requested_factor = 0.03;
    }

    $margin = $current_price * ($location_factor - $rate_history_factor + $gallons_requested_factor + $company_profit_factor);
    $suggested_price = $current_price + $margin;
    $total_amount = $gallons * $suggested_price;

    $response['suggested_price'] = $suggested_price;
    $response['total_amount'] = $total_amount;

    return $response;
}

function hasHistory($userid = null) {
    $con = getMySQLiConnection();

    if(is_null($userid)){
        $userid = $_SESSION['id'];
    }
    $sql = $con->prepare("select * from fuelquote where userid = ? limit 1");
    $sql->bind_param("s", $userid);
    $sql->execute();

    $result = $sql->get_result();
    if ($result->num_rows > 0) {
        return true;
    } else {
        return false;
    }
}

// //////////////////////////////////////////////
function updateProfile($name, $address1, $address2, $city, $state, $zip, $userid = null)
{
    $con = getMySQLiConnection();

    $response = array();
    $userid = $_SESSION['id'];
    $stmt = $con->prepare("INSERT INTO `clientinformation`(`userid`, `name`, `address1`, `address2`, `city`, `state`, `zip`) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $userid, $name, $address1, $address2, $city, $state, $zip);

    if ($stmt->execute()) {
        $response['message'] = "Profile Updated successfully";
        $response['status'] = "success";
        $_SESSION['address'] = $address1;
        $_SESSION['state'] = $state;

    } else {
        
        $response['message'] = "Unable to update profile.";
        $response['status'] = "failed";

    }

    return $response;
}
