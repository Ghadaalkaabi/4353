<?php

/************************************************************
 * 
 * Include functions.php
 * 
 * **********************************************************
 */
include_once './functions.php';

if (isset($_POST["action"]) && $_POST["action"] == "addFuelQuote") {

	$gallons = htmlspecialchars($_POST["gallons"]);
	$date = htmlspecialchars($_POST["date"]);
	$suggested = htmlspecialchars($_POST["suggested"]);
	$total = htmlspecialchars($_POST["total"]);
	
	$response = addFuelQuote($gallons, $date, $suggested, $total);
}

if (isset($_POST["action"]) && $_POST["action"] == "getHistory") {

	$response = getHistory();
}

echo json_encode($response);