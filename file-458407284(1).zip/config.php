<?php
ini_set('display_errors', 1);
	
function getPDOConnection(){
    $db = new PDO("mysql:host=localhost;dbname=uvo_fuel", "root", "password");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $db;
}

function getMySQLiConnection(){
    $db = new mysqli("localhost", "root", "password", "uvo_fuel", 3306);
    $db->set_charset("utf8");
    return $db;
}
