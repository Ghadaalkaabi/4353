<?php
/************************************************************
 * 
 * Include functions.php
 * 
 * **********************************************************
 */
include_once './functions.php';

if (isset($_POST["action"]) && $_POST["action"] == "getQuote") {
	$gallons = htmlspecialchars($_POST["gallons"]);

	$response = getQuote($gallons);
	
}

echo json_encode($response);