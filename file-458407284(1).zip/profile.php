<?php
/************************************************************
 * 
 * Include functions.php
 * 
 * **********************************************************
 */
include_once './functions.php';

if (isset($_POST["action"]) && $_POST["action"] == "updateProfile") {
	$name = htmlspecialchars($_POST["name"]);
	$address1 = htmlspecialchars($_POST["address1"]);
	$address2 = htmlspecialchars($_POST["address2"]);
	$city = htmlspecialchars($_POST["city"]);
	$state = htmlspecialchars($_POST["state"]);
	$zip = htmlspecialchars($_POST["zip"]);
	$response = updateProfile($name, $address1, $address2, $city, $state, $zip);
	
}
	
echo json_encode($response);