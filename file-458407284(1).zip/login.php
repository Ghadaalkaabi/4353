<?php

/************************************************************
 * 
 * Include functions.php
 * 
 * **********************************************************
 */
include_once './functions.php';

if (isset($_POST["action"]) && $_POST["action"] == "userLogin") {
	$username = htmlspecialchars($_POST["username"]);
	$password = htmlspecialchars($_POST["password"]);
	$response = userLogin($username, $password);
	
}

if (isset($_POST["action"]) && $_POST["action"] == "registerUser") {
	$username = htmlspecialchars($_POST["username"]);
	$password = htmlspecialchars($_POST["password"]);
	$response = registerUser($username, $password);
	
}

if (isset($_POST["action"]) && $_POST["action"] == "getAddress") {
	$response = getAddress();
	
}

echo json_encode($response);