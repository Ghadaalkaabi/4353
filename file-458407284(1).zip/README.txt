To run tests in this project, use the following command:
    
    -> cd tests
    -> ../vendor/bin/phpunit AppTest.php --colors

All tests are registered in the AppTest class found 
in the tests/AppTest.php file.